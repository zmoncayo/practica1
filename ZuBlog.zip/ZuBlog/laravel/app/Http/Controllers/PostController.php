<?php

//namespace blog\Http\Controllers\Post;
namespace blog\Http\Controllers;
use blog\Post;
use Illuminate\Http\Request;
use DB;
use blog\Http\Request\PostRequest;
use Auth;


//use Illuminate\Html;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = trim($request->get('search'));
        $publicaciones = DB::table('posts')->where([
            ['userid','=', Auth::user()->id],
            ['title','LIKE','%'.$query.'%'],
            ['status','=','A'],
        ])
        ->orWhere([
            ['userid','=',Auth::user()->id],
            ['description','LIKE','%'.$query.'%'],
            ['status','=','A'],
        ])
        ->orderby('updated_at','desc')->paginate(5);
        return view('post.index',["publicaciones"=>$publicaciones,"search"=>$query]);
    }

     public function blog(Request $request)
    {
        $query = trim($request->get('search'));
        $publicaciones = DB::table('posts')->where([
            ['title','LIKE','%'.$query.'%'],
            ['status','=','A'],
        ])
        ->orWhere([
            ['description','LIKE','%'.$query.'%'],
            ['status','=','A'],
        ])
        ->orderby('updated_at','desc')->paginate(5);
        //Pruebas
        /*
        $username = DB::table('posts')->join('users','id','=','userid')
        ->select('posts.*','users.name'); */


         $comentarios = DB::table('comments')->where('status','=','A')->paginate(5);

        return view('home',["publicaciones"=>$publicaciones,"comentarios"=>$comentarios]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Post.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $post = new Post;

        $post->title = $request->title;
        $post->description = $request->description;
        $post->userid = $request->userid;

        $post->save();

        return redirect('post')->with('msgs','Publicación creada exitosamente');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $post = Post::find($id);
        if (! $post) {
            abort(404);
        }
        return view('Post.edit',compact('post'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $post = Post::find($id);

        $post->title = $request->title;
        $post->description = $request->description;

        $post->update();

        return redirect()->route('post.index')->with('msgs','Publicación actualizada exitosamente');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Post::find($id);
        $post->status = 'I';
        $post->update();

        return redirect()->route('post.index');
    }
}
