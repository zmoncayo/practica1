<?php

namespace blog;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $table = 'comments';
    protected $primaryKey = "id";
    
    public $timestamps = true;
    protected $fillable = [
       'id',
       'user_id',
       'body',
       'status' 
    ];

      protected $guarded = [

    ];
}
