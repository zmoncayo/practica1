@extends('layouts.app')

@section('content')
             <h1 class="text-primary">Publicaciones</h1>

            <br>
            <br>
            <div class="col-md-12">
               @include('Post.success')
                @foreach ($publicaciones as $publicacion)
                 {!!Form::open(array('url'=>'comment','method'=>'POST','autocomplete'=>'off'))!!}
                   {{Form::token()}}
                   <input type="hidden" name="userid" value="{{ Auth::user()->id }}">
                    <div class="panel panel-primary">
                        <div class="panel-heading">{{$publicacion->title}}</div>
                        <div class="panel-body">
                          {{$publicacion->description}}
                          <br></br> <hr>
                          <h6>Creado por:  Fecha: {{$publicacion->created_at}}  Ultima modificación: 
                        {{$publicacion->updated_at}}</h6>
                        </div>
                      <!-- listar comentarios -->      
              
                      <div class="panel-footer">
                        <div>
                          @foreach ($comentarios as $comentario)
                          <div class="alert alert-success">
                            <ul>
                              <li>{{$comentario->body}}</li>
                            </ul>
                          </div>
                            @endforeach 
                        </div>  

         
                        <div><textarea class="form-control" name="body"> </textarea></div>
                        <br>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Comentar</button>
                            <a href="" class="btn btn-danger">Eliminar</a>
                        </div>
                      </div>

                 {!!Form::close()!!}
                    </div>            
                      
                 <br></br>
                   @include('Post.delete')
                @endforeach
            </div>
            {{$publicaciones->render()}}
         
         

@endsection