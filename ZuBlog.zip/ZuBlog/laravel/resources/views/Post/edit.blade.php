@extends('layouts.app')

@section('content')
	
	@include('Post.error')
 
		    {!!Form::model($post,['method'=>'PATCH','route'=>['post.update',$post->id]])!!}
		   

		     @include('Post.form')

		    {!!Form::close()!!}

@endsection