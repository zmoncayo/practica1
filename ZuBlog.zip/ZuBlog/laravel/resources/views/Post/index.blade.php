@extends('layouts.app')

@section('content')
            <h1 class="text-primary">Publicaciones</h1>

            <br>
            <br>
            <div class="col-md-12">
               @include('Post.success')
                @foreach ($publicaciones as $publicacion)
                    <div class="panel panel-primary">
                      <div class="panel-heading">{{$publicacion->title}}</div>
                      <div class="panel-body">
                        {{$publicacion->description}}
                        <br></br> <hr>
                        <h6>Creado: {{$publicacion->created_at}}  Ultima modificación: 
                      {{$publicacion->updated_at}}</h6>
                      </div>
                      <div class="panel-footer ">
                        <a href="{{URL::action('PostController@edit',$publicacion->id)}}">
                                <button class="btn btn-info">Editar</button>
                        </a>
                        <a href="#modal-delete-{{$publicacion->id}}" data-toggle="modal">
                                <button class="btn btn-danger">Eliminar</button>
                        </a>
                      </div>
                    </div>            
                      
                 <br></br>
                   @include('Post.delete')
                @endforeach
            </div>
            {{$publicaciones->render()}}
         
		

@endsection