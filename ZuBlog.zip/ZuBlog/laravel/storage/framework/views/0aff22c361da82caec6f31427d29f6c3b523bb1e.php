<?php $__env->startSection('content'); ?>
             <h1 class="text-primary">Publicaciones</h1>

            <br>
            <br>
            <div class="col-md-12">
               <?php echo $__env->make('Post.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php echo Form::open(array('url'=>'comment','method'=>'POST','autocomplete'=>'off')); ?>

                   <?php echo e(Form::token()); ?>

                   <input type="hidden" name="userid" value="<?php echo e(Auth::user()->id); ?>">
                    <div class="panel panel-primary">
                        <div class="panel-heading"><?php echo e($publicacion->title); ?></div>
                        <div class="panel-body">
                          <?php echo e($publicacion->description); ?>

                          <br></br> <hr>
                          <h6>Creado por:  Fecha: <?php echo e($publicacion->created_at); ?>  Ultima modificación: 
                        <?php echo e($publicacion->updated_at); ?></h6>
                        </div>
                      <!-- listar comentarios -->      
              
                      <div class="panel-footer">
                        <div>
                          <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="alert alert-success">
                            <ul>
                              <li><?php echo e($comentario->body); ?></li>
                            </ul>
                          </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>  

         
                        <div><textarea class="form-control" name="body"> </textarea></div>
                        <br>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Comentar</button>
                            <a href="" class="btn btn-danger">Eliminar</a>
                        </div>
                      </div>

                 <?php echo Form::close(); ?>

                    </div>            
                      
                 <br></br>
                   <?php echo $__env->make('Post.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($publicaciones->render()); ?>

         
         

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>