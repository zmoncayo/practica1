 

<?php $__env->startSection('content'); ?>
	
	<?php echo $__env->make('Post.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo Form::open(array('url'=>'post','method'=>'POST','autocomplete'=>'off')); ?>

    <?php echo e(Form::token()); ?>


     <?php echo $__env->make('Post.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>