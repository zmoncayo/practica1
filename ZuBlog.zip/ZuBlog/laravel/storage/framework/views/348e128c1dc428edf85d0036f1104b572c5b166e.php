<?php if(Session::has('msgs')): ?>
	<div class="alert alert-success">
		<button type='button' class="close" data-dismiss="alert">
			&times;
		</button>

		<ul>
			<li><?php echo e(Session::get('msgs')); ?></li>
		</ul>
	</div>
<?php endif; ?>