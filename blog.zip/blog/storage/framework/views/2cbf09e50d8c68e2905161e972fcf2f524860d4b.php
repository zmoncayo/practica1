<?php $__env->startSection('content'); ?>

            <div class="col-md-12">
               <?php echo $__env->make('Post.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-primary">
                      <div class="panel-heading"><?php echo e($publicacion->title); ?></div>
                      <div class="panel-body">
                        <?php echo e($publicacion->description); ?>

                        <br></br> <hr>
                        <h6><strong>Publicado por: </strong><?php echo e($publicacion->name); ?> <strong>Creado:</strong> <?php echo e($publicacion->created_at); ?></h6>
                      </div>
                      <div class="panel-footer ">
                        <a href="<?php echo e(URL::action('PostController@edit',$publicacion->idpost)); ?>">
                                <button class="btn btn-info">Editar</button>
                        </a>
                        <a href="#modal-delete-<?php echo e($publicacion->idpost); ?>" data-toggle="modal">
                                <button class="btn btn-danger">Eliminar</button>
                        </a>
                      </div>
                    </div>            
                      
                 <br></br>
                   <?php echo $__env->make('Post.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($publicaciones->render()); ?>

         
		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>