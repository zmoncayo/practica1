<?php $__env->startSection('content'); ?>
    <div class="page-content">
    	<div class="row">
		 
		  <div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-body">
			        <h1 class="text-primary">Publicaciones</h1>

			            <br>
			            <br>
			            <div class="col-md-12">
			                <?php $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                    <div class="panel panel-primary">
			                      <div class="panel-heading"><?php echo e($publicacion->title); ?></div>
			                      <div class="panel-body">
			                        <?php echo e($publicacion->description); ?>

			                        <br></br> <hr>
			                        <h6><strong>Publicado por:</strong>  <?php echo e($publicacion->name); ?>  <strong>Creado:</strong>  <?php echo e($publicacion->created_at); ?>  <strong>Ultima modificación:</strong> 
			                      <?php echo e($publicacion->updated_at); ?></h6>
			                      </div>
			                      <div class="panel-footer ">
			                        <a href="<?php echo e(URL::action('CommentController@show',$publicacion->idpost)); ?>">
			                                <button class="btn btn-info">Ver comentarios</button>
			                        </a>
			                        <a href="<?php echo e(URL::action('CommentController@create',['id'=>$publicacion->idpost])); ?>">
			                                <button class="btn btn-primary">Agegar un comentarios</button>
			                        </a>
			                      </div>

			                    </div>            
			                      
			                 <br></br>
			                   <?php echo $__env->make('Post.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            </div>
			            <?php echo e($publicaciones->render()); ?>

		  		</div>
			</div>		
		 </div>  
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>