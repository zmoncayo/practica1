<?php $__env->startSection('content'); ?>

            <div class="col-md-12">
               <?php echo $__env->make('Post.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="panel panel-primary">
                      <div class="panel-heading"><?php echo e($publicacion->title); ?></div>
                      <div class="panel-body">
                        <?php echo e($publicacion->description); ?>

                        <br></br> <hr>
                        <h6><strong>Creado:</strong> <?php echo e($publicacion->created_at); ?></h6>
                      </div>
                      <div class="panel-footer ">
                        <ul>
                          <?php if($comentarios->count() > 0): ?>
                            <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li class="">
                              Usuario <strong> <?php echo e($comentario->name); ?>  </strong> comentó: <strong class="text-primary"><?php echo e($comentario->body); ?></strong> 
                              &nbsp &nbsp &nbsp &nbsp
                               <strong>  Fecha: </strong> <?php echo e($comentario->created_at); ?>

                                <hr>
                            </li>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                          <?php else: ?>
                            <li class="alert alert-success"> <h5>No hay publicaciones</h5></li>
                          <?php endif; ?>                          
                          
                        </ul>
                      </div>
                    </div>            
                      
                 <br></br>
                   <?php echo $__env->make('Post.delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>

         
		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>