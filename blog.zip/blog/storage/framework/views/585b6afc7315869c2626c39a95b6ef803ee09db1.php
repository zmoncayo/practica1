<input type="hidden" name="userid" value="<?php echo e(Auth::user()->id); ?>">
<input type="hidden" name="postid" value="<?php echo e($_GET['id']); ?>">
<div class="form-group">
	<?php echo Form::label('body','Descripción:'); ?>

	<?php echo Form::textarea('body',null,['class'=>'form-control','placeholder'=>'Escriba aquí su publicación...']); ?>

</div>
<div class="form-group">
    <button class="btn btn-primary" type="submit">Guardar</button>
    <button class="btn btn-danger" type="reset">Cancelar</button>
</div>
