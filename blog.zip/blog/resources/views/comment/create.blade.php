@extends('layouts.app')

@section('content')
	
	@include('Post.error')

    {!!Form::open(array('url'=>'comment','method'=>'POST','autocomplete'=>'off'))!!}
    {{Form::token()}}

     @include('comment.form')

    {!!Form::close()!!}

@endsection