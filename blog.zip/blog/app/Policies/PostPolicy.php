<?php

namespace Blog\Policies;

use Blog\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Blog\Post;
class PostPolicy
{
    use HandlesAuthorization;

  

}
